//
//  SelectorViewController.swift
//  TimeZoneApp
//
//  Created by lab on 11/19/25.
//

import UIKit
import Macaw

let zones = [
"Pacific/Honolulu",
"America/Anchorage",
"America/Los_Angeles",
"America/Phoenix",
"America/Denver",
"America/Chicago",
"America/New_York",
"Atlantic/Bermuda",
"America/Sao_Paulo",
"Europe/London",
"Europe/Paris",
"Europe/Berlin",
"Africa/Johannesburg",
"Asia/Dubai",
"Asia/Kolkata",
"Asia/Shanghai",
"Asia/Tokyo",
"Australia/Sydney",
"Pacific/Auckland"
]

var timeZones: [TimeZone] =
{
    zones.compactMap { TimeZone(identifier: $0) }
}()

class SelectorViewController: UIViewController, UIPickerViewDataSource, UIPickerViewDelegate {
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return zones.count
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return zones[row]
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        selectedZone = TimeZone(identifier: zones[row])!
        print("Selected time zone: ", selectedZone)
        highlightCountry("us")
    }
    

    override func viewDidLoad() {
        super.viewDidLoad()
        
        TimeZonePicker.delegate = self
        TimeZonePicker.dataSource = self
    }
    
    @IBOutlet weak var TimeZonePicker: UIPickerView!
    @IBOutlet weak var svgView: SVGView!
    
    /*enum Zones: String, CaseIterable {
        case UTC-12, UTC-11, UTC-10, UTC-9, UTC-8, UTC-7, UTC-6, UTC-5, UTC-4, UTC-3, UTC-2, UTC-1, UTC, UTC+1, UTC+2, UTC+3, UTC+4, UTC+5, UTC+6, UTC+7, UTC+8, UTC+9, UTC+10, UTC+11, UTC+12, UTC+13, UTC+14
        var id: Self { self }
    }*/
    
    var selectedZone = TimeZone.current
    
    func highlightCountry(_ countryID: String, color: Color = .yellow)
    {
        guard let node = svgView.node.nodeBy(tag: countryID) as? Shape else { return }
        
        node.fill = color
    }
}

