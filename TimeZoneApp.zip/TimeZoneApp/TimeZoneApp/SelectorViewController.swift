//
//  SelectorViewController.swift
//  TimeZoneApp
//
//  Created by lab on 11/19/25.
//

import UIKit
import Macaw

let zones = [
"Pacific/Honolulu",
"America/Anchorage",
"America/Los_Angeles",
"America/Phoenix",
"America/Denver",
"America/Chicago",
"America/New_York",
"Atlantic/Bermuda",
"America/Sao_Paulo",
"Europe/London",
"Europe/Paris",
"Europe/Berlin",
"Africa/Johannesburg",
"Asia/Dubai",
"Asia/Kolkata",
"Asia/Shanghai",
"Asia/Tokyo",
"Australia/Sydney",
"Pacific/Auckland"
]

var timeZones: [TimeZone] =
{
    zones.compactMap { TimeZone(identifier: $0) }
}()

class SelectorViewController: UIViewController, UIPickerViewDataSource, UIPickerViewDelegate {
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return zones.count
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return zones[row]
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        selectedZone = TimeZone(identifier: zones[row])!
        print("Selected time zone: ", selectedZone)
    }
    

    override func viewDidLoad() {
        super.viewDidLoad()
        
        TimeZonePicker.delegate = self
        TimeZonePicker.dataSource = self
        
        updateTime()
        startTimer()
    }
    
    @IBOutlet weak var TimeZonePicker: UIPickerView!
    @IBOutlet weak var timeLabel: UILabel!
    var timer: Timer?
    
    var selectedZone = TimeZone.current

    func startTimer()
    {
        timer = Timer.scheduledTimer(timeInterval: 1.0,
                                     target: self,
                                     selector: #selector(updateTime),
                                     userInfo: nil,
                                     repeats: true)
    }
    
    @objc func updateTime()
    {
        let formatter = DateFormatter()
        formatter.timeZone = selectedZone
        formatter.timeStyle = .medium
        formatter.dateStyle = .short
        timeLabel.text = formatter.string(from: Date())
    }
    
}

