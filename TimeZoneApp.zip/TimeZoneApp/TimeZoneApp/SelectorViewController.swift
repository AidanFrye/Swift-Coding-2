//
//  SelectorViewController.swift
//  TimeZoneApp
//
//  Created by lab on 11/19/25.
//

import UIKit
import SwiftUICore

class SelectorViewController: UIViewController, UIPickerViewDataSource, UIPickerViewDelegate {
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return zones.count
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return zones[row].rawValue
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        selectedZone = zones[row]
        print("Selected time zone: ", selectedZone.rawValue)
    }
    

    override func viewDidLoad() {
        super.viewDidLoad()
        
        TimeZonePicker.delegate = self
        TimeZonePicker.dataSource = self
        
        selectedZone = .EST
    }
    
    @IBOutlet weak var TimeZonePicker: UIPickerView!

    enum Zones: String, CaseIterable {
        case EST, CST, PST, GMT
        var id: Self { self }
    }
    
    let zones = Zones.allCases
    
    var selectedZone: Zones = .EST
}

