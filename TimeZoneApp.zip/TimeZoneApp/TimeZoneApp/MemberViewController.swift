//
//  ViewController.swift
//  TimeZoneApp
//
//  Created by lab on 11/19/25.
//

import UIKit

class MemberViewController: UIViewController, AddMemberDelegate {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //UserDefaults.standard.removeObject(forKey: "members")
        if(!didLoadMembers)
        {
            loadMembers()
        }
        startTimer()
        // Do any additional setup after loading the view.
    }
    
    @IBOutlet weak var stackView: UIStackView!
    @IBOutlet weak var scrollView: UIScrollView!
    
    var members = [Member]()
    var timer: Timer?
    var timeLabels = [UILabel]()
    var didLoadMembers = false
    var selectedMember: Member?
    
    func addMember(_ member: Member, _ save: Bool) {
        let memberView = createMemberView(member)
        let height: Double = Double(members.count) * 58.0
        scrollView.contentSize = CGSize(width: scrollView.frame.width, height: height)
        stackView.addArrangedSubview(memberView)
        if(save)
        {
            members.append(member)
            saveMembers()
        }
    }
    
    func saveMembers()
    {
        let encoder = JSONEncoder()
        if let encoded = try? encoder.encode(members) {
            UserDefaults.standard.set(encoded, forKey: "members")
        }
    }
    
    func loadMembers()
    {
        if(didLoadMembers) { return; }
        didLoadMembers = true
        
        if let savedMembers = UserDefaults.standard.data(forKey: "members")
        {
            let decoder = JSONDecoder()
            if let data = try? decoder.decode([Member].self, from: savedMembers)
            {
                members = data
            }
            for member in members {
                addMember(member, false)
            }
        }
    }
    
    func startTimer()
    {
        timer = Timer.scheduledTimer(timeInterval: 1.0,
                                     target: self,
                                     selector: #selector(updateTime),
                                     userInfo: nil,
                                     repeats: true)
    }
    
    @objc func updateTime()
    {
        let formatter = DateFormatter()
        formatter.timeStyle = .short
        formatter.dateStyle = .none
        
        var i = 0
        for member in members
        {
            formatter.timeZone = member.timeZone
            timeLabels[i].text = formatter.string(from: Date())
            i += 1
        }
    }
    
    func createMemberView(_ member: Member) -> UIView
    {
        let name = member.name
        let timeZone = member.timeZone
        let container = UIView()
        container.tag = timeLabels.count
        container.backgroundColor = .systemGray6
        container.layer.cornerRadius = 8
        container.translatesAutoresizingMaskIntoConstraints = false
        container.heightAnchor.constraint(equalToConstant: 50).isActive = true
        
        let nameLabel = UILabel()
        nameLabel.text = name
        nameLabel.font = UIFont.systemFont(ofSize: 18, weight: .medium)
        nameLabel.translatesAutoresizingMaskIntoConstraints = false
        
        container.addSubview(nameLabel)
        
        NSLayoutConstraint.activate([nameLabel.leadingAnchor.constraint(equalTo: container.leadingAnchor, constant: 16), nameLabel.centerYAnchor.constraint(equalTo: container.centerYAnchor)])
        
        let timeLabel = UILabel()
        
        let formatter = DateFormatter()
        formatter.timeZone = timeZone
        formatter.timeStyle = .short
        formatter.dateStyle = .none
        timeLabel.text = formatter.string(from: Date())
        
        timeLabel.font = UIFont.systemFont(ofSize: 18, weight: .medium)
        timeLabel.translatesAutoresizingMaskIntoConstraints = false
        
        container.addSubview(timeLabel)
        timeLabels.append(timeLabel)
        
        NSLayoutConstraint.activate([timeLabel.trailingAnchor.constraint(equalTo: container.trailingAnchor, constant: -16), timeLabel.centerYAnchor.constraint(equalTo: container.centerYAnchor)])
        
        let tap = UITapGestureRecognizer(target: self, action: #selector(memberTapped(_:)))
        container.isUserInteractionEnabled = true
        container.addGestureRecognizer(tap)
        
        return container
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?)
    {
        if (segue.identifier == "AddMemberSegue")
        {
            if let navController = segue.destination as? UINavigationController,
               let addVC = navController.topViewController as? AddMemberViewController
            {
                addVC.delegate = self
            }
        }
    }
    
    @objc func memberTapped(_ sender: UITapGestureRecognizer)
    {
        guard let containerView = sender.view else { return }
        let member = containerView.tag
        
        selectedMember = members[member]
        
        highlightSelectedMember(member)
    }
    
    func highlightSelectedMember(_ member: Int)
    {
        for view in stackView.subviews {
            if view.tag == member
            {
                view.backgroundColor = .systemBlue
            } else
            {
                view.backgroundColor = .systemGray5
            }
        }
    }
    
    @IBAction func planMeetingPressed(_ sender: Any) {
        if let tbVC = tabBarController,
           let meetingVC = tabBarController!.viewControllers?[0] as? MeetingViewController {
            meetingVC.selectedZone1 = TimeZone.current
            if(selectedMember != nil)
            {
                meetingVC.selectedZone2 = selectedMember!.timeZone
            }
            tbVC.selectedIndex = 0
        }
    }
    
}

