//
//  ViewController.swift
//  TimeZoneApp
//
//  Created by lab on 11/19/25.
//

import UIKit

class MemberViewController: UIViewController, AddMemberDelegate {
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        addMembers(members)
    }
    

    @IBOutlet weak var stackView: UIStackView!
    @IBOutlet weak var scrollView: UIScrollView!
    
    var members = ["Aidan", "Owen", "Beckett"]
    
    func addMembers(_ names: [String])
    {
        for name in names
        {
            let memberView = createMemberView(name: name)
            let height: Double = Double(members.count) * 58.0
            scrollView.contentSize = CGSize(width: scrollView.frame.width, height: height)
            stackView.addArrangedSubview(memberView)
        }
    }
    
    
    func addMember(_ name: String) {
        members.append(name)
        let memberView = createMemberView(name: name)
        let height: Double = Double(members.count) * 58.0
        scrollView.contentSize = CGSize(width: scrollView.frame.width, height: height)
        stackView.addArrangedSubview(memberView)
        print("delegate triggered")
    }
    
    func createMemberView(name: String) -> UIView
    {
        let container = UIView()
        container.backgroundColor = .systemGray6
        container.layer.cornerRadius = 8
        container.translatesAutoresizingMaskIntoConstraints = false
        container.heightAnchor.constraint(equalToConstant: 50).isActive = true
        
        let label = UILabel()
        label.text = name
        label.font = UIFont.systemFont(ofSize: 18, weight: .medium)
        label.translatesAutoresizingMaskIntoConstraints = false
        
        container.addSubview(label)
        
        NSLayoutConstraint.activate([label.leadingAnchor.constraint(equalTo: container.leadingAnchor, constant: 16), label.centerYAnchor.constraint(equalTo: container.centerYAnchor)])
        
        return container
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?)
    {
        if (segue.identifier == "AddMemberSegue")
        {
            if let navController = segue.destination as? UINavigationController,
               let addVC = navController.topViewController as? AddMemberViewController
            {
                addVC.delegate = self
            }
        }
    }
}

