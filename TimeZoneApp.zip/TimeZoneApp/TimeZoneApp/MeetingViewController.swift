import UIKit
import EventKit
import EventKitUI
import SwiftUICore

class MeetingViewController: UIViewController, UIPickerViewDelegate, UIPickerViewDataSource, EKEventEditViewDelegate, UINavigationControllerDelegate {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        TimeZonePicker1.delegate = self
        TimeZonePicker2.delegate = self
        
        TimeZonePicker1.dataSource = self
        TimeZonePicker2.dataSource = self
        
        updateTime()
        startTimer()
        buildTimeline()
    }
    
    override func viewWillAppear(_ animated: Bool)
    {
        super.viewWillAppear(animated)
        buildTimeline()
        updatePickers()
    }
    
    let store = EKEventStore()
    var timer: Timer?
    var selectedHour: Int = 0
    let calendar = Calendar.current
    
    func startTimer()
    {
        timer = Timer.scheduledTimer(timeInterval: 1.0,
                                     target: self,
                                     selector: #selector(updateTime),
                                     userInfo: nil,
                                     repeats: true)
    }
    
    func updatePickers()
    {
        if let index = zones.firstIndex(of: selectedZone1.identifier) {
            TimeZonePicker1.selectRow(index, inComponent: 0, animated: true)
        }
        if let index = zones.firstIndex(of: selectedZone2.identifier){
            TimeZonePicker2.selectRow(index, inComponent: 0, animated: true)
        }
    }
    
    @objc func updateTime()
    {
        let formatter = DateFormatter()
        formatter.timeZone = selectedZone1
        formatter.timeStyle = .short
        formatter.dateStyle = .none
        uiLabel1.text = formatter.string(from: Date())
        formatter.timeZone = selectedZone2
        uiLabel2.text = formatter.string(from: Date())
    }
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return zones.count
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return zones[row]
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        if (pickerView.tag == 1) {
            selectedZone1 = TimeZone(identifier: zones[row])!
            print("Selected time zone 1: ", selectedZone1)
        }
        if (pickerView.tag == 2) {
            selectedZone2 = TimeZone(identifier: zones[row])!
            print("Selected time zone 2: ", selectedZone2)
        }
        buildTimeline()
    }
    
    func hourString(for hour: Int, in zone: TimeZone) -> String
    {
        var dateComponents = calendar.dateComponents([.year, .month, .day], from: Date())
        dateComponents.hour = hour
        dateComponents.minute = 0
        dateComponents.second = 0
        
        let date = calendar.date(from: dateComponents)!
        
        let formatter = DateFormatter()
        formatter.timeZone = zone
        formatter.dateFormat = "h:mm a"
        
        return formatter.string(from: date)
    }
    
    func hourInZone(_ date: Date, zone: TimeZone, offset: Int) -> Int
    {
        var dateComponents = DateComponents()
        dateComponents.timeZone = zone
        dateComponents.hour = calendar.component(.hour, from: date)
        
        return dateComponents.hour! + offset
    }
    
    func buildTimeline()
    {
        timelineView.subviews.forEach { $0.removeFromSuperview() }
        
        let zone1 = selectedZone1
        let zone2 = selectedZone2
        
        let width: CGFloat = 90
        let height: CGFloat = timelineView.frame.height
        for hour in 0..<24
        {
            
            let hour1 = hourInZone(Date(), zone: zone1, offset: hour)
            let hour2 = hourInZone(Date(), zone: zone2, offset: hour)

            
            let x = CGFloat(hour) * width
            
            let container = UIView(frame: CGRect(x: x, y: 0, width: width, height: height))
            
            let divider = UIView(frame: CGRect(x: 0, y: height / 2 + 10, width: width, height: 30))
            container.addSubview(divider)
            
            let zoneLabel1 = UILabel(frame: CGRect(x: 0, y: 10, width: width, height: 30))
            zoneLabel1.textAlignment = .center
            zoneLabel1.text = hourString(for: hour1, in: zone1)
            
            let tap = UITapGestureRecognizer(target: self, action: #selector(hourTapped(_:)))
            container.isUserInteractionEnabled = true
            container.addGestureRecognizer(tap)
            container.tag = hour
            
            container.addSubview(zoneLabel1)
            let zoneLabel2 = UILabel(frame: CGRect(x: 0, y: height/2 + 10, width: width, height: 30))
            zoneLabel2.textAlignment = .center
            zoneLabel2.text = hourString(for: hour2, in: zone2)
            container.addSubview(zoneLabel2)
            
            timelineView.addSubview(container)
        }
     
        timelineView.frame.size.width = CGFloat(24) * width
        scrollView.contentSize = timelineView.frame.size
    }
    
    @objc func hourTapped(_ sender: UITapGestureRecognizer)
    {
        guard let containerView = sender.view else { return }
        let hour = containerView.tag
        
        selectedHour = hour
        
        highlightSelectedHour(hour)
    }
    
    func highlightSelectedHour(_ hour: Int)
    {
        for view in timelineView.subviews {
            if view.tag == hour {
                view.backgroundColor = .systemBlue
            } else
            {
                view.backgroundColor = .systemGray5
            }
        }
        print(selectedHour)
    }
        
    var selectedZone1 = TimeZone.current
    var selectedZone2 = TimeZone.current
    
    @IBOutlet weak var TimeZonePicker1: UIPickerView!
    @IBOutlet weak var TimeZonePicker2: UIPickerView!
    @IBOutlet weak var uiLabel1: UILabel!
    @IBOutlet weak var uiLabel2: UILabel!
    
    @IBOutlet weak var scrollView: UIScrollView!
    @IBOutlet weak var timelineView: UIView!
    @IBOutlet weak var hourIndicator: UIView!
    
    @IBAction func createMeetingPressed(_ sender: Any) {
        store.requestFullAccessToEvents() { (granted, error) in
            guard granted else { return }
        }
        
        var calendar = Calendar.current
        calendar.timeZone = selectedZone1
        var dateComponents = calendar.dateComponents([.year, .month, .day, .hour], from: Date())
        var offset = dateComponents.hour
        dateComponents.hour = selectedHour + offset!
        dateComponents.minute = 0
        
        let eventDate = calendar.date(from: dateComponents)
        
        let newEvent = EKEvent(eventStore: self.store)
        newEvent.title = "New Meeting"
        newEvent.startDate = eventDate
        newEvent.timeZone = selectedZone1
        newEvent.endDate = eventDate?.addingTimeInterval(3600)
        newEvent.calendar = self.store.defaultCalendarForNewEvents
        let otherVC = EKEventEditViewController()
        otherVC.eventStore = self.store
        otherVC.editViewDelegate = self
        otherVC.event = newEvent
        self.present(otherVC, animated: true, completion: nil)
    }
    
    //----------------- EVENT CREATION AND MANAGEMENT ---------------
    func eventEditViewController(_ controller: EKEventEditViewController, didCompleteWith action: EKEventEditViewAction) {
        controller.dismiss(animated: true)
    }
}
