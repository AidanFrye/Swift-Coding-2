import UIKit
import SwiftUICore

class MeetingViewController: UIViewController, UIPickerViewDelegate, UIPickerViewDataSource {
    
    enum Zones: String, CaseIterable {
        case EST, CST, PST, GMT
        var id: Self { self }
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        TimeZonePicker1.delegate = self
        TimeZonePicker2.delegate = self
        
        TimeZonePicker1.dataSource = self
        TimeZonePicker2.dataSource = self
    }
    
    let zones = Zones.allCases
    
    var selectedZone1: Zones = .EST
    var selectedZone2: Zones = .EST
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return zones.count
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return zones[row].rawValue
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        if (pickerView.tag == 1) {
            selectedZone1 = zones[row]
            print("Selected time zone 1: ", selectedZone1.rawValue)
        }
        if (pickerView.tag == 2) {
            selectedZone2 = zones[row]
            print("Selected time zone 2: ", selectedZone2.rawValue)
        }
    }
        
        
        @IBOutlet weak var TimeZonePicker1: UIPickerView!
        @IBOutlet weak var TimeZonePicker2: UIPickerView!
}
