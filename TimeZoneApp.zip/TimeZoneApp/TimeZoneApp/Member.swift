//
//  Member.swift
//  TimeZoneApp
//
//  Created by lab on 12/7/25.
//

import UIKit

struct Member: Codable {

    var name: String = ""
    var timeZone: TimeZone = TimeZone.current
    
    init(name: String, timeZone: TimeZone) {
        self.name = name
        self.timeZone = timeZone
    }
    
}
