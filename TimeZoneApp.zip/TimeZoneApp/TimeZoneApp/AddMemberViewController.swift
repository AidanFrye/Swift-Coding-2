import UIKit

class AddMemberViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    weak var delegate: AddMemberDelegate?
    let controller = MemberViewController()
    @IBOutlet weak var backButton: UINavigationItem!
    @IBAction func backButtonPressed(_ sender: Any)
    {
        dismiss(animated: true, completion: nil)
    }
    
    @IBAction func saveButtonPressed(_ sender: Any)
    {
        delegate?.addMember("Polly")
        dismiss(animated: true, completion: nil)
    }
}
protocol AddMemberDelegate: AnyObject {
    func addMember(_ name: String)
}


