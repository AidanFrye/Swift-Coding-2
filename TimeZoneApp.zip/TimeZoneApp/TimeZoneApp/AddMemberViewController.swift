import UIKit

class AddMemberViewController: UIViewController, UIPickerViewDataSource, UIPickerViewDelegate {
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return zones.count
    }
    
    
    @IBOutlet weak var TextField: UITextField!
    @IBOutlet weak var TimeZonePicker: UIPickerView!
    var selectedZone = TimeZone.current
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        TimeZonePicker.delegate = self
        TimeZonePicker.dataSource = self
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return zones[row]
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        selectedZone = TimeZone(identifier: zones[row])!
        print("Selected time zone: ", selectedZone)
    }
    
    weak var delegate: AddMemberDelegate?
    let controller = MemberViewController()
    @IBOutlet weak var backButton: UINavigationItem!
    @IBAction func backButtonPressed(_ sender: Any)
    {
        dismiss(animated: true, completion: nil)
    }
    
    @IBAction func saveButtonPressed(_ sender: Any)
    {
        if let text = TextField.text?.trimmingCharacters(in: .whitespacesAndNewlines), !text.isEmpty {
            let newMember = Member(name: TextField.text!, timeZone: selectedZone)
            delegate?.addMember(newMember, true)
            dismiss(animated: true, completion: nil)
        }
    }
}

protocol AddMemberDelegate: AnyObject {
    func addMember(_ member: Member, _ save: Bool)
}


